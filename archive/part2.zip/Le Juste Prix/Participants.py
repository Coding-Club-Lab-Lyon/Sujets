import random
import time


Products = {
    "Ecran" : {
        "name" : "Ecer Gaming",
        "price" : random.randint(180, 230)
    },

    "Console" : {
        "name" : "Nantendo Swatch",
        "price" : random.randint(250, 320)
    },
}

Dialogue = [
    "",
    "Voix-off : Bonjour et bienvenue au Good Price, avec pour présentateur, Vincent FAIGAF !",
    "Vincent Faigaf : BIP BIP",
    "Le public : OUAIIIIIIS !",
    "Vincent Faigaf : Et on commence tout de suite par la présentation de nos candidats !",
    "Notre premier candidat est : ",
    "Il affrontera : ",
    "Nous allons tout de suite commencer avec le premier produit.",
]


def CustomPrint(text, sleep_time):


def StoryTeller():


def PlayerTurnVerification(valuePlayer, price, nextPlayerName):


def RegisterPlayer(player1, player2):


def Main():
    playerOne = input("Comment vous appelez vous ? (Premier joueur) : ")
    playerTwo = input("Comment vous appelez vous ? (Second joueur) : ")

Main()
