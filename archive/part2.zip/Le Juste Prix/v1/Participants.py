import random
import time

Products = {
    "Ecran" : {
        "name" : "Ecer Gaming",
        "price" : random.randint(180, 230)
    },
    "Console" : {
        "name" : "Nantendo Swatch",
        "price" : random.randint(250, 320)
    },
}

Dialogue = [
    "Voix off : Bonjour et bienvenue au Good Price, avec pour présentateur, Vincent FAIGAF !",
    "Vincent Faigaf : BIP BIP",
    "Le public : OUAIIII !",
    "Vincent Faigaf : Et on commence tout de suite avec nos premiers candidats !",
    "Nous allons tout de suite commencer avec le premier produit."
]

def CustomPrint(text, sleep_time):

def StoryTeller():

def PlayerTurnVerification(valuePlayer, price, nextPlayerName):

def Main():

Main()